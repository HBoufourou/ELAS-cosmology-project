
## ELAS – validation snapshot (v0.1.0)

This release ships a minimal public artefact set for the ELAS vs LCDM validation:
- Overleaf bundle (`elas_overleaf_bundle_YYYYMMDD_HHMMSS.zip`) with figures/ and tables/
- Key summary figures:
  - phase9_executive_summary_dashboard.png
  - phase6_weighted_map.png
- Key tables/summaries:
  - phase9_executive_summary.csv
  - phase6_weighted_summary.json

Notes:
- Data in this snapshot may include lightweight/synthetic stand-ins when official calibrated datasets were not available.
- The pipeline supports SNe, BAO, and CC combinations; metrics include chi^2, delta-chi^2, AIC/BIC and PPC-LEE meta-analysis.

Next:
- Replace demo placeholders with official, calibrated data.
- Re-run phases 4–9 and regenerate the Overleaf bundle for the manuscript.

License: MIT
