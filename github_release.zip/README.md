
# ELAS Cosmology Project

**Author:** Hicham Boufourou  
**Version:** 1.0.0  
**Release Date:** 2025-10-25  
**Repository:** [https://github.com/HBoufourou/ELAS-cosmology-project](https://github.com/HBoufourou/ELAS-cosmology-project)  
**License:** MIT  

---

### Description
This repository contains the complete validation and simulation pipeline for the **Elastic Lambda-Structure (ELAS)** cosmological model.

The project tests ΛCDM versus ELAS variants using SNe, BAO, and CC data, includes MCMC inference, physical diagnostics, and Overleaf-ready figures for publication.

---

### License
Distributed under the **MIT License**. See the `LICENSE` file for details.

---

### Repository structure
ELAS/
 ├─ notebooks/            # Main analysis notebooks
 ├─ output/               # Results, figures, and tables
 ├─ overleaf/             # Export bundle for LaTeX
 ├─ github_release/       # Files prepared for GitHub
 └─ requirements.txt      # Python dependencies

---

### Citation
If you use this repository, please cite:

> H. Boufourou, "Elastic Lambda-Structure Cosmology (ELAS): empirical validation and framework", 2025 (in preparation).
